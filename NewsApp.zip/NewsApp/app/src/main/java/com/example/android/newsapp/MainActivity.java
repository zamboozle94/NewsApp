package com.example.android.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.android.newsapp.NewsItem;
import com.example.android.newsapp.NewsItemAdapter;
import com.example.android.newsapp.NewsLoader;
import com.example.android.newsapp.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<NewsItem>> {

    private NewsItemAdapter mAdapter;
    private TextView mEmptyStateTextView;
    private ProgressBar progressBar;

    //an array to hold all the news source icon image locations
    private ArrayList<Integer> newsSourceIcons = new ArrayList<>();
    //an array to hold all the news source names
    private ArrayList<String> newsSourceName = new ArrayList<>();

    private static String NEWS_REQUEST_URL = "https://newsapi.org/v2/top-headlines?sources=abc-news-au,buzzfeed,entertainment-weekly,the-guardian-au,the-new-york-times,news-com-au,time&apiKey=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create news source icons
        initialiseNewsSourceIcons();

        //create a new adapter that takes an empty array of books as its input
        mAdapter = new NewsItemAdapter(MainActivity.this, new ArrayList<NewsItem>());

        //establish the progress bar
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);

        //establish the list of search results
        final ListView newsResults = (ListView) findViewById(R.id.headlines_list);
        //set the adapter to the @link searchResults
        newsResults.setAdapter(mAdapter);

        //setup an on item click listener that when a news item is clicked opens up the news information in a web browser
        newsResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                NewsItem currentNewsItem = mAdapter.getItem(position);
                String urlToGoTo = currentNewsItem.getmUrl();
                Uri webpage = Uri.parse(urlToGoTo);
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

        //setup the empty state textview in the event in needs to be used. Also set up progress bar.
        mEmptyStateTextView = (TextView) findViewById(R.id.no_results);
        //set the list empty state to the empty state text view
        newsResults.setEmptyView(mEmptyStateTextView);


        // Once everything has been establish, start the URL request
        // Get a reference to the ConnectivityManager to check state of network connectivity
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        //Get details of current network status
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        // If there is a network connection, fetch data
        if (networkInfo != null && networkInfo.isConnected()) {
            // Get a reference to the LoaderManager, in order to interact with loaders.
            LoaderManager loaderManager = getLoaderManager();

            loaderManager.initLoader(1, null, this);
        } else {
            // Otherwise, display error
            // First, hide loading indicator so error message will be visible
            View loadingIndicator = findViewById(R.id.progress_bar);
            loadingIndicator.setVisibility(View.GONE);

            // Update empty state with no connection error message
            mEmptyStateTextView.setText(R.string.no_network_connection);
        }

        /*
         * Sets up a SwipeRefreshLayout.OnRefreshListener that is invoked when the user
         * performs a swipe-to-refresh gesture.
         * When user swipes-to-refresh check if the user has internet access and perform URL request for
         * news articles
         */
        final SwipeRefreshLayout refreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshNewsArticles();
                refreshLayout.setRefreshing(false);
            }
        });

    }

    @Override
    public Loader<List<NewsItem>> onCreateLoader(int i, Bundle bundle) {
        // Create a new loader for the given URL
        return new NewsLoader(this, NEWS_REQUEST_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<NewsItem>> loader, List<NewsItem> books) {
        mEmptyStateTextView.setText(R.string.no_results);
        progressBar.setVisibility(View.GONE);
        // Clear the adapter of previous earthquake data
        mAdapter.clear();

        // If there is a valid list of {@link Earthquake}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (books != null && !books.isEmpty()) {
            mAdapter.addAll(books);
        }

    }

    @Override
    public void onLoaderReset(Loader<List<NewsItem>> loader) {
        // Loader reset, so we can clear out our existing data.
        mAdapter.clear();
    }

    public static void setRequestUrl(String newUrl) {
        NEWS_REQUEST_URL = newUrl;
    }

    private void initialiseNewsSourceIcons() {
        newsSourceIcons.add(R.drawable.abc_news_au);
        newsSourceName.add("ABC News");

        newsSourceIcons.add(R.drawable.buzzfeed);
        newsSourceName.add("Buzzfeed");

        newsSourceIcons.add(R.drawable.entertainment_weekly);
        newsSourceName.add("Entertainment Weekly");

        newsSourceIcons.add(R.drawable.guardian_au);
        newsSourceName.add("Guardian AU");

        newsSourceIcons.add(R.drawable.new_york_times);
        newsSourceName.add("New York Times");

        newsSourceIcons.add(R.drawable.news_com_au);
        newsSourceName.add("News.com.au");

        newsSourceIcons.add(R.drawable.time);
        newsSourceName.add("Time");

        initRecyclerView();
    }

    private void initRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.icon_list);
        recyclerView.setLayoutManager(linearLayoutManager);
        NewsIconAdapter newsIconAdapter = new NewsIconAdapter(this, newsSourceIcons, newsSourceName);
        recyclerView.setAdapter(newsIconAdapter);
    }

    /*
     *Method is called when a refresh is needed to the news article list. This method implements the refresh method of the loader
     */

    public void refreshNewsArticles() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        //Get details of current network status
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            // Get a reference to the LoaderManager, in order to interact with loaders.
            LoaderManager loaderManager = getLoaderManager();

            loaderManager.restartLoader(1, null, this);
        } else {
            // Otherwise, display error
            // First, hide loading indicator so error message will be visible
            View loadingIndicator = findViewById(R.id.progress_bar);
            loadingIndicator.setVisibility(View.GONE);

            // Update empty state with no connection error message
            mEmptyStateTextView.setText(R.string.no_network_connection);
        }
    }

}
