package com.example.android.newsapp;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class NewsIconAdapter extends RecyclerView.Adapter<NewsIconAdapter.NewsIcon> {

    private ArrayList<Integer> mNewsSourceIconsLocation;
    private ArrayList<String> mNewsSourceIconsNames;
    private ArrayList<String> currentNewsSourcesActive;
    private Context mContext;

    public NewsIconAdapter(Context context, ArrayList<Integer> newsSourceIcons, ArrayList<String> newsSourceIconsNames) {
        mNewsSourceIconsLocation = newsSourceIcons;
        mNewsSourceIconsNames = newsSourceIconsNames;
        mContext = context;
        currentNewsSourcesActive = new ArrayList<String>();
        initialiseCurrentNewsSources();
    }

    private void initialiseCurrentNewsSources() {
        currentNewsSourcesActive.add("ABC News");
        currentNewsSourcesActive.add("Buzzfeed");
        currentNewsSourcesActive.add("Entertainment Weekly");
        currentNewsSourcesActive.add("Guardian AU");
        currentNewsSourcesActive.add("New York Times");
        currentNewsSourcesActive.add("News.com.au");
        currentNewsSourcesActive.add("Time");
    }

    @Override
    public NewsIcon onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_source_icon, parent, false);
        return new NewsIcon(view);
    }

    @Override
    public void onBindViewHolder(final NewsIcon holder, final int position) {
        //attaches the images to the icons
        holder.mNewsIconImageView.setImageResource(mNewsSourceIconsLocation.get(position));
        //attaches the names to the icons
        holder.mNewsIconName = mNewsSourceIconsNames.get(position);

        //set an listen that when an icon is clicked a toast message appears
        holder.mNewsIconImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if current news source is active set it to non active(greyed-out)
                //else activate current news source and ungrey it
                if (holder.mNewsIconImageView.getTag() != "grayed" ) {
                    holder.mNewsIconImageView.setColorFilter(Color.argb(150, 200, 200, 200));
                    holder.mNewsIconImageView.setTag("grayed");
                    currentNewsSourcesActive.remove(currentNewsSourcesActive.indexOf(mNewsSourceIconsNames.get(position)));
                } else {
                    holder.mNewsIconImageView.setColorFilter(null);
                    holder.mNewsIconImageView.setTag("");
                    currentNewsSourcesActive.add(mNewsSourceIconsNames.get(position));
                }

                //run the get url method to generate the url to query for the active news sources
                getNewUrl();
            }
        });

    }

    private void getNewUrl() {
        String newUrl = "https://newsapi.org/v2/top-headlines?sources=";

        //if all news sources are greyed out, exit early
        if(currentNewsSourcesActive.size() == 0){
            MainActivity.setRequestUrl("");
        }

        for (int i = 0; i < currentNewsSourcesActive.size(); i++){
            switch (currentNewsSourcesActive.get(i)) {
                case "ABC News":
                    newUrl += "abc-news-au,";
                    break;
                case "Buzzfeed":
                    newUrl += "buzzfeed,";
                    break;
                case "Entertainment Weekly":
                    newUrl += "entertainment-weekly,";
                    break;
                case "Guardian AU":
                    newUrl += "the-guardian-au,";
                    break;
                case "New York Times":
                    newUrl += "the-new-york-times,";
                    break;
                case "News.com.au":
                    newUrl += "news-com-au,";
                    break;
                case "Time":
                    newUrl += "time,";
                    break;
            }
        }
        newUrl = newUrl.substring(0,newUrl.length()-1);
        newUrl += "&apiKey=";
        MainActivity.setRequestUrl(newUrl);
    }

    @Override
    public int getItemCount() {
        return mNewsSourceIconsLocation.size();
    }

    public class NewsIcon extends RecyclerView.ViewHolder {
        ImageView mNewsIconImageView;
        String mNewsIconName;

        public NewsIcon(View itemView) {
            super(itemView);
            mNewsIconImageView = itemView.findViewById(R.id.news_source_icon);
            mNewsIconName = "";
        }
    }

}
