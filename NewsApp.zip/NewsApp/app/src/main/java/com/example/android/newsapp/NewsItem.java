package com.example.android.newsapp;

public class NewsItem {

    private String mNewsHeadline;
    private String mNewsDescription;
    private String mNewsSource;
    private String mUrl;

    public NewsItem(String newsHeadline, String newsDescription, String newsSource, String url){
        mNewsHeadline = newsHeadline;
        mNewsDescription = newsDescription;
        mNewsSource = newsSource;
        mUrl = url;
    }

    public String getNewsHeadline() {
        return mNewsHeadline;
    }

    public String getNewsDescription() {
        return mNewsDescription;
    }

    public String getNewsSource() { return mNewsSource; }

    public String getmUrl(){ return mUrl; }
}
