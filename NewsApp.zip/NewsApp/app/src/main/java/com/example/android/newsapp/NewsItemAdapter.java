package com.example.android.newsapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsItemAdapter extends ArrayAdapter<NewsItem> {

    public NewsItemAdapter(Activity activity, ArrayList<NewsItem> books){
        super(activity, 0, books);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listView = convertView;
        if (listView == null){
            listView = LayoutInflater.from(getContext()).inflate(R.layout.news_article, parent, false);
        }

        NewsItem currentNewsItem = getItem(position);

        //get the headline of the current news item in the list and set it to the corresponding textView
        TextView currentNewsHeadlineTextView = (TextView) listView.findViewById(R.id.headline);
        // response has headline in format "Headline - source". Want to remove "- part"
        String currentHeadline = currentNewsItem.getNewsHeadline();
        int lastHyphenPosition = currentHeadline.lastIndexOf("-");
        if(lastHyphenPosition > -1) {
            currentHeadline = currentHeadline.substring(0, lastHyphenPosition);
        }

        currentNewsHeadlineTextView.setText(currentHeadline);

        //get the description of the current news item in the list and set it to the corresponding textView
        TextView currentNewsDescriptionTextView = (TextView) listView.findViewById(R.id.description);

        //check if description is null, if is want to display a blank string
        String currentDescription = currentNewsItem.getNewsDescription();
        if (currentDescription.compareTo("null") == 0){
            currentDescription = "";
        }
        currentNewsDescriptionTextView.setText(currentDescription);

        //get the source of the current news item in the list and set it to the corresponding textView
        TextView currentNewsSourceTextView = (TextView) listView.findViewById(R.id.link_to_article);
        currentNewsSourceTextView.setText(currentNewsItem.getNewsSource());

        return listView;
    }
}
